##### this function reads out loud every line that is in the file ‘labels.txt’ #####

After each sound sample was played, press any button to continue.

Make sure, that all necessary files (START.sh, label_teller_EEG.py, labels.txt) are located in the same folder.

Start the reader by executing ‘START.sh’ 

Libraries needed in order to run the Python script:
- os
- time
- re
- gtts

Please note, that in order to play the respective sound, a temporary ‘*.mp3’ files is created in the very same folder.